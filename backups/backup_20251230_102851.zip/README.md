# SC Manager — Master Server (sc_manager_master_server)

Minimal scaffold for the Master Server authority crate. This crate contains the authoritative signing and registry responsibilities and is intentionally minimal for initial integration and testing.

Run tests:

```bash
cd services/master-server
cargo test
```
